import single from './single/single';
import group from './group/group';
import filternext from './filternext/filternext';

export default [single, group, filternext];
